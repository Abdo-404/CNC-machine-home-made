<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <message>
        <source>User button</source>
        <translation>Пользовательская кнопка</translation>
    </message>   
    <name>frmMain</name>
    <message>
        <source>User commands</source>
        <translation>Пользовательские команды</translation>
    </message>   
    </context>
    <context>
    <name>UserCommandsSettings</name>
    <message>
        <source>Hint</source>
        <translation>Описание</translation>
    </message>   
    <message>
        <source>Icon</source>
        <translation>Значок</translation>
    </message> 
    <message>
        <source>G-code</source>
        <translation>G-код</translation>
    </message> 
    <message>
        <source>Up</source>
        <translation>Вверх</translation>
    </message> 
    <message>
        <source>Down</source>
        <translation>Вниз</translation>
    </message> 
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message> 
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message> 
    <message>
        <source>Remove all</source>
        <translation>Удалить все</translation>
    </message> 
</context>
</TS>