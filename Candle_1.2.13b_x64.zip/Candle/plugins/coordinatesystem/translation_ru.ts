<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>frmMain</name>
    <message>
        <source>Coordinate system</source>
        <translation>Система координат</translation>
    </message>   
    </context>
    <context>
    <name>CoordinateSystem</name>
    <message>
        <source>Offsets:</source>
        <translation>Смещения:</translation>
    </message>          
    <message>
        <source>Zero X</source>
        <translation>Обнулить X</translation>
    </message>          
    <message>
        <source>Zero Y</source>
        <translation>Обнулить Y</translation>
    </message>          
    <message>
        <source>Zero Z</source>
        <translation>Обнулить Z</translation>
    </message>          
    <message>
        <source>Zero All</source>
        <translation>Обнулить все</translation>
    </message>          
</context>
</TS>